﻿namespace AxUnityWebPlayerAXLib
{
    using System;

    public class _DUnityWebPlayerAXEvents_OnExternalCallEvent
    {
        public string value;

        public _DUnityWebPlayerAXEvents_OnExternalCallEvent(string value)
        {
            this.value = value;
        }
    }
}

