﻿namespace AxUnityWebPlayerAXLib
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void _DUnityWebPlayerAXEvents_OnExternalCallEventHandler(object sender, _DUnityWebPlayerAXEvents_OnExternalCallEvent e);
}

