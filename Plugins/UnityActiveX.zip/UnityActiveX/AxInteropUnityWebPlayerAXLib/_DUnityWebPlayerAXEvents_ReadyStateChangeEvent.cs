﻿namespace AxUnityWebPlayerAXLib
{
    using System;

    public class _DUnityWebPlayerAXEvents_ReadyStateChangeEvent
    {
        public int readyState;

        public _DUnityWebPlayerAXEvents_ReadyStateChangeEvent(int readyState)
        {
            this.readyState = readyState;
        }
    }
}

