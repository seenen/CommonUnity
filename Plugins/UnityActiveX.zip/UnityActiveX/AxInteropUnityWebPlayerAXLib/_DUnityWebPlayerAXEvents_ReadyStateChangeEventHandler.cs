﻿namespace AxUnityWebPlayerAXLib
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void _DUnityWebPlayerAXEvents_ReadyStateChangeEventHandler(object sender, _DUnityWebPlayerAXEvents_ReadyStateChangeEvent e);
}

